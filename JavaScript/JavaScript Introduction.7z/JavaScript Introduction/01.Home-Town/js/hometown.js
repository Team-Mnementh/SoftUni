var hometown = "Petrich";

alert(hometown);