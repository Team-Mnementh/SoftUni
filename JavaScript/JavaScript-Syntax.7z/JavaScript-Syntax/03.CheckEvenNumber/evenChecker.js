function evenNumber (value) {
	if (value % 2 === 0) {
		console.log(true);
	}
	else{
		console.log(false);
	}
}
evenNumber(3);
evenNumber(127);
evenNumber(588);