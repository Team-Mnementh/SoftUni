function variablesTypes (value) {
	console.log('My name: ' + value[0] + ' //type is ' + typeof(value[0]));
	console.log('My age: ' + value[1] + ' //type is ' + typeof(value[1]));
	console.log('I am male: ' + value[2] + ' //type is ' + typeof(value[2]));
	console.log('My favorite foods are: ' + value[3] + ' //type is ' + typeof(value[3]));
}
variablesTypes(['Pesho', 22, true,['fries','banana','cake']]);