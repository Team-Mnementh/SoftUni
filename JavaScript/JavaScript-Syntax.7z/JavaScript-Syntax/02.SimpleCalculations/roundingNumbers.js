function roundNumber (value) {
	console.log(Math.floor(value) + "---> Math.floor()");
	console.log(Math.round(value) + "-> Math.round()");
}
roundNumber(22.7);
roundNumber(12.3);
roundNumber(58.7);