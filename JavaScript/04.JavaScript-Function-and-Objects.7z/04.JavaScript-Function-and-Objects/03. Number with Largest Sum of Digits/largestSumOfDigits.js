function findLargestBySumOfDigits(nums) {
	var hello = 1;
	console.log(Number.isInteger(1));
}

findLargestBySumOfDigits();